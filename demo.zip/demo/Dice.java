package com.example.demo;

public class Dice {

    public int getRolledValue()
    {
        return (int)(Math.random()*6+1);
    }
}
